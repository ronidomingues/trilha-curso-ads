<?php 
include __DIR__ . '/forms/cabecalho.php'; 
?>

  <main class="main">

    <!-- Hero Section -->
    <section id="hero" class="hero section dark-background">
      <img src="<?php echo BASE_URL ?>/assets/img/logo-site.jpg" alt="" data-aos="fade-in">
 
      <div class="container">
        <div class="row">
          <div class="col-xl-4">
            <h1 data-aos="fade-up">Módulo de BackEnd</h1>
            <blockquote data-aos="fade-up" data-aos-delay="100">
              <p>O módulo de backend gerencia a lógica do servidor, a integração com bancos de dados, a autenticação de usuários, e o processamento de solicitações, fornecendo as respostas necessárias ao frontend. </p>
            </blockquote>
            <div class="d-flex" data-aos="fade-up" data-aos-delay="200">
              <a href="index.php" class="btn-get-started">Iniciar</a>
              <a href="https://youtu.be/wHtyxpIsZ7o" class="glightbox btn-watch-video d-flex align-items-center"><i class="bi bi-play-circle"></i><span>Assista o Video</span></a>
            </div>
          </div>

          <!-- FORMULÁRIO DO EXERCÍCIO -->
          <?php 
              if (isset($_GET['page'])) {
                $pagina = $_GET['page']; 

                if ($pagina == "exercicio1Sequencial"){
                  include(__DIR__ . '/forms/Exerc1SeqForm.php');
                }

              } 
          ?>
  

        </div>
      </div>
    </section>

  </main>

<?php 
include __DIR__ . '/forms/rodape.php'; 
?>

