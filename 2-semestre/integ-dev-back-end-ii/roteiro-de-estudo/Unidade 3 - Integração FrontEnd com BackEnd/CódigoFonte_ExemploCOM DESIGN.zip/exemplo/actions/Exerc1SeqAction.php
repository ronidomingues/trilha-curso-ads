<?php

function calcularArea($r, $a){
    if (!empty($r) && !empty($a) && $a >= 0 && $r >= 0) {
        $v = 3.14159 * $r * $r * $a;
        echo "<p style='font-family: Arial, sans-serif; font-size: 15px; color: #167439; text-align: center;'>Resultado: $v </p>";
    }else {
        echo "<p style='font-family: Arial, sans-serif; font-size: 15px; color:# a40606; text-align: center'>Por favor, preencha todos os campos corretamente.</p>";
    }    
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $raio = htmlspecialchars($_POST['raio']);
    $altura = htmlspecialchars($_POST['altura']);
    
    calcularArea($raio, $altura);

} else {
    echo "<p style='font-family: Arial, sans-serif; font-size: 15px; color: #a40606; text-align: center'>Dados não enviados corretamente.</p>";
}

?>
