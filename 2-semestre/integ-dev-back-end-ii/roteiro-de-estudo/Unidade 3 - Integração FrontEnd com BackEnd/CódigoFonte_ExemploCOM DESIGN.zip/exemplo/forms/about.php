<?php 
include("cabecalho.php"); 
?>

  <main class="main">

    <!-- Page Title -->
    <div class="page-title dark-background" data-aos="fade" style="background-image: url(assets/img/logo-sobre.jpg);">
      <div class="container">
        <h1>Sobre</h1>
        <nav class="breadcrumbs">
          <ol>
            <li><a href="<?php echo BASE_URL; ?>/index.php">Home</a></li>
            <li class="current">Sobre</li>
          </ol>
        </nav>
      </div>
    </div><!-- End Page Title -->

    <!-- About Section -->
    <section id="about" class="about section">

      <div class="container">

        <div class="row gy-4" data-aos="fade-up" data-aos-delay="100">
          <div class="col-lg-5">
            <img src="<?php echo BASE_URL; ?>/assets/img/sobre-conheca.png" class="img-fluid" alt="">
          </div>
          <div class="col-lg-7" data-aos="fade-up" data-aos-delay="200">
            <div class="content">
              <h3>Conheça Nosso Site de Exercícios PHP</h3>
              <p>
                o propósito deste site é servir como um exemplo de integração entre frontend e backend. 
                O foco é oferecer resoluções de exercícios simples para praticar comandos básicos de PHP, 
                incluindo estruturas sequenciais, condicionais, de repetição e listas. 
                Através deste ambiente interativo, usuários podem aplicar e aprimorar suas habilidades em programação, 
                compreendendo a aplicação prática da lógica de desenvolvimento web.
              </p>
              <ul>
                <li><i class="bi bi-check-circle-fill"></i> <span>Resolução de Problemas.</span></li>
                <li><i class="bi bi-check-circle-fill"></i> <span>Conhecimento de Estruturas de Controle.</span></li>
                <li><i class="bi bi-check-circle-fill"></i> <span>Integração de Tecnologias.</span></li>
              </ul>
            </div>
          </div>
        </div>

      </div>

    </section><!-- /About Section -->

    <!-- Team Section -->
    <section id="team" class="team section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Nossa Turma</h2>
        <p>Descubra os talentos da nossa turma - juntos, estamos moldando o futuro da programação!</p>
      </div><!-- End Section Title -->

      <div class="container">

        <div class="row gy-4">

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="team-member">
              <div class="member-img">
                <img src="<?php echo BASE_URL; ?>/assets/img/alunos/antoniopedro.png" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter-x"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Antonio Pedro</h4>
              </div>
            </div>
          </div><!-- End Team Member -->

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
            <div class="team-member">
              <div class="member-img">
                <img src="<?php echo BASE_URL; ?>/assets/img/alunos/patrickneves.png" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter-x"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Patrick Neves</h4>
              </div>
            </div>
          </div><!-- End Team Member -->

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="300">
            <div class="team-member">
              <div class="member-img">
                <img src="<?php echo BASE_URL; ?>/assets/img/alunos/lorena.png" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter-x"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Lorena</h4>
              </div>
            </div>
          </div><!-- End Team Member -->

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="400">
            <div class="team-member">
              <div class="member-img">
                <img src="<?php echo BASE_URL; ?>/assets/img/alunos/eduardolucas.png" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter-x"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Eduardo Lucas</h4>
              </div>
            </div>
          </div><!-- End Team Member -->

        </div>

      </div>

    </section><!-- /Team Section -->

  </main>

  <?php include("rodape.php"); ?>