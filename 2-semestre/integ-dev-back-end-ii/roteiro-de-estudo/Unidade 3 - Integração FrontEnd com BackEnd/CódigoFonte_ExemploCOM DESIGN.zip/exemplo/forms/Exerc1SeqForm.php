          <div class="col-xl-6" style="padding-left: 200px; flex: auto;">
            <div class="title-container">
              <h2>Enunciado - Exercício 1 - Estrutura Sequencial</h2>
              <p>Dado o valor da Altura e o Raio de uma lata de óleo pelo usuário, calcular e apresentar o valor do volume da lata de óleo, utilizando
              a fórmula: VOLUME = 3.14159 * R * R * ALTURA.</p>
            </div>

            <div class="form-container">
              <form action="<?php echo BASE_URL ?>/actions/Exerc1SeqAction.php" method="post" target="resultado" onsubmit="validaForm(event)">
                <div class="mb-3">
                  <label for="raio" class="form-label">Raio</label>
                  <input type="number" class="form-control" id="raio" name="raio" step="0.01" required>
                </div>
                <div class="mb-3">
                  <label for="altura" class="form-label">Altura</label>
                  <input type="number" class="form-control" id="altura" name="altura" step="0.01" required>
                </div>
                <button type="submit" class="btn btn-primary">Calcular</button>
              </form>
            </div>

            <div class="response-container" id="response" style="display: none;">
                <h2>Resposta</h2>
                <!-- Local para exibir a resposta do PHP -->
                <iframe name="resultado" id="resultado" style="width:100%; height:25px; border:none;"></iframe>
            </div>
          </div>



