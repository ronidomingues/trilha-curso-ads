<?php 
define('BASE_URL', '/exemplo');
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Aula BackEnd</title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <link href="<?php echo BASE_URL; ?>/assets/img/coruja.png" rel="icon">
  <link href="<?php echo BASE_URL; ?>/assets/img/coruja.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo BASE_URL; ?>/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo BASE_URL; ?>/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="<?php echo BASE_URL; ?>/assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="<?php echo BASE_URL; ?>/assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="<?php echo BASE_URL; ?>/assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="<?php echo BASE_URL; ?>/assets/css/main.css" rel="stylesheet">

</head>

<body class="index-page">

  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center justify-content-between">

      <a href="<?php echo BASE_URL; ?>/index.php" class="logo d-flex align-items-center">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <img src="<?php echo BASE_URL; ?>/assets/img/coruja-logo.png" alt="">
        <h1 class="sitename">Turma ADS0202N</h1>
      </a>

      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="<?php echo BASE_URL; ?>/index.php" class="active">Home<br></a></li>
          <li><a href="<?php echo BASE_URL; ?>/forms/about.php">Sobre</a></li>
          <li class="dropdown"><a href="#"><span>Sequencial</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
            <ul>
              <li><a href="<?php echo BASE_URL; ?>/index.php?page=exercicio1Sequencial">Exercício 1</a></li>
              <li><a href="#">Exercício 2</a></li>
              <li><a href="#">Exercício 3</a></li>
              <li><a href="#">Exercício 4</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>Condicional</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
            <ul>
              <li><a href="#">Exercício 1</a></li>
              <li><a href="#">Exercício 2</a></li>
              <li><a href="#">Exercício 3</a></li>
              <li><a href="#">Exercício 4</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>Repetição</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
            <ul>
              <li><a href="#">Exercício 1</a></li>
              <li><a href="#">Exercício 2</a></li>
              <li><a href="#">Exercício 3</a></li>
              <li><a href="#">Exercício 4</a></li>
            </ul>
          </li>
          <li class="dropdown"><a href="#"><span>Listas</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
            <ul>
              <li><a href="#">Exercício 1</a></li>
              <li><a href="#">Exercício 2</a></li>
              <li><a href="#">Exercício 3</a></li>
              <li><a href="#">Exercício 4</a></li>
            </ul>
          </li>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>

    </div>
  </header>
