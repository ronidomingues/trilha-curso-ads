<footer id="footer" class="footer light-background">
    <div class="container copyright text-center">
      <p>© <span>Copyright</span> <strong class="px-1 sitename">Turma ADS0202N</strong> <span>Todos os Direitos Reservados</span></p>
    </div>

  </footer>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo BASE_URL; ?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo BASE_URL; ?>/assets/vendor/php-email-form/validate.js"></script>
  <script src="<?php echo BASE_URL; ?>/assets/vendor/aos/aos.js"></script>
  <script src="<?php echo BASE_URL; ?>/assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="<?php echo BASE_URL; ?>/assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="<?php echo BASE_URL; ?>/assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="<?php echo BASE_URL; ?>/assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>

  <!-- Main JS File -->
  <script src="<?php echo BASE_URL; ?>/assets/js/main.js"></script>

</body>

</html>